export const data = {
    "status": true,
    "data": [
        {
            "category": "Shinchan",
            "question": "What is the name of Shinchan's favourite action hero?",
            "marks": 5,
            "answers": [
                {
                    "answer": "James Bond",
                    "isCorrect": false
                },
                {
                    "answer": "Action Kamen",
                    "isCorrect": true
                },
                {
                    "answer": "Captain Shinchan",
                    "isCorrect": false
                },
                {
                    "answer": "Sailor Moon",
                    "isCorrect": false
                }
            ]
        },
        {
            "category": "Shinchan",
            "question": "What is the vegetable that Shinchan hates to eat?",
            "marks": 5,
            "answers": [
                {
                    "answer": "Carrot",
                    "isCorrect": false
                },
                {
                    "answer": "Garlic",
                    "isCorrect": false
                },
                {
                    "answer": "Beans",
                    "isCorrect": false
                },
                {
                    "answer": "Capsicum",
                    "isCorrect": true
                }
            ]
        },
        {
            "category": "TMKOC",
            "question": "What is the full name of Jethalal ?",
            "marks": 5,
            "answers": [
                {
                    "answer": "Jethalal Tapu Gada",
                    "isCorrect": false
                },
                {
                    "answer": "Jethalal Daya Gada",
                    "isCorrect": false
                },
                {
                    "answer": "Jethalal Champaklal Gada",
                    "isCorrect": true
                },
                {
                    "answer": "Jethalal Jayantilal Gada",
                    "isCorrect": false
                }
            ]
        },
        {
            "category": "TMKOC",
            "question": "What is the name of the company where Popatlal works as a reporter?",
            "marks": 5,
            "answers": [
                {
                    "answer": "Toofan Express",
                    "isCorrect": true
                },
                {
                    "answer": "Aandhi Express",
                    "isCorrect": false
                },
                {
                    "answer": "Express Mail",
                    "isCorrect": false
                },
                {
                    "answer": "Toofan Mail",
                    "isCorrect": false
                }
            ]
        },
        {
            "category": "TMKOC",
            "question": "Who is the best friend of jethalal ?",
            "marks": 5,
            "answers": [
                {
                    "answer": "Krishnan Iyer",
                    "isCorrect": false
                },
                {
                    "answer": "Tarak Mehta",
                    "isCorrect": true
                },
                {
                    "answer": "Roshan Singh Sodhi",
                    "isCorrect": false
                },
                {
                    "answer": "Atmaram Bhide",
                    "isCorrect": false
                }
            ]
        }
    ]
}